# Claude Code Prompt — Use the FMD Mascot Asset Pack for Homepage Redesign

Before editing code, inspect the current FMD homepage structure and the supplied mascot pack.

## Read these files first

- `README.md` in this pack.
- `production/FMD_meditating_mascot_master.png` and its WebP counterpart.
- All boards in `reference/` for character consistency and semantic pose direction.

## Critical rules

1. The standalone meditating PNG/WebP is the only production-ready standalone pose in this starter pack. Do not crop the small mascot thumbnails out of the reference boards and use them as full-size page images.
2. Do not invent that a 2D PNG can perform true 3D body rotation. The Blender 3D model will be supplied later. In the meantime, keep the current asset usage honest and use subtle position/opacity transitions only where suitable.
3. The mascot is a helper and narrator, not the hero of every section. Product content and the visitor's needs must remain dominant.
4. Maintain character consistency: rounded pearl-white tooth head, simple expressive face, white coat, deep sapphire scrubs, controlled blue rim light and soft realistic shading.
5. Don't add Earth backgrounds to every section. Reserve the detailed Earth scene for the hero and the appropriate closing vision/Coming Soon section.
6. Follow the implementation scope most recently specified by the user. If any section is explicitly marked locked/unchanged in the active task, do not modify it.

## Semantic placement guide

Use this as design intent, not permission to fake unavailable artwork:

- Hero: preserve or use the calm meditating pose where appropriate.
- Search bar: small, supportive guide/pointing pose in a future individual asset; don't dominate the input.
- AI model features: a welcoming/open pose, with restrained orbital feature nodes; the nodes explain the model's capabilities.
- FMD walkthrough: a guide/pointing pose beside the step sequence; keep the content and path as the focus.
- Learn from verified dentists: attentive/curious expression, with the educational content and creator identity in focus.
- Dental journey: guiding/walking pose following the journey line; the journey is the visual protagonist.
- Private Vault: focused, careful pose alongside the records UI; emphasize privacy and organization.
- FMD Edge/Concierge: reassuring, welcoming pose; use the established warm champagne/silver accent treatment if that section already calls for it.
- Discover Dentist: curious/searching pose beside real provider cards.
- Metrics/Trust: calm, confident expression; credibility should come from real data and accurate labels, not mascot exaggeration.
- FMD OS products: studying/reading pose for Scholar and working/laptop pose for Clinic OS when those assets are produced.
- Coming Soon: rear-facing seated mascot looking toward the horizon; this requires a separate rear-view asset, so don't fake a back view by flipping the front image.

## Implementation steps

1. Audit existing components and assets before changing files.
2. Map each existing section to its purpose, main CTA, product UI and semantic mascot role.
3. Copy only production assets into the public asset directory; keep reference boards in documentation.
4. Build the new layouts with real HTML/CSS and actual UI components, not as one flattened background image.
5. Reuse the shared design tokens and keep the background premium: layered navy/black gradient, glassy sapphire surfaces used sparingly, controlled light, continuous transitions and varied section compositions.
6. Keep the mascot subordinate to the content; avoid placing it in every card or using the same pose in every section.
7. Where a semantic pose is missing, create a clearly named placeholder slot/data mapping for a future asset rather than using a collage crop. Use the supplied master temporarily only where it makes visual sense.
8. Preserve responsive behaviour, accessibility, reduced-motion support and existing functionality.
9. After implementation, run lint/typecheck/build, inspect real browser screenshots, and report missing pose assets explicitly.

## Expected deliverables

- A section-by-section homepage implementation consistent with the active scope.
- A list of production assets used and where they are used.
- A list of required future mascot renders/model clips, such as `guide-pointing`, `listening`, `thinking`, `working-laptop`, `studying`, `reassuring`, `rear-facing-seated`.
- No false claims that the placeholder asset is a rigged model or that missing poses have been delivered.
