# FMD Mascot Asset Pack — Starter v1

This pack supports the FMD homepage redesign and gives Claude Code a consistent character reference.

## Included production assets

- `production/FMD_meditating_mascot_master.png` — approved standalone transparent mascot master (2260 × 2260 px).
- `production/FMD_meditating_mascot_master.webp` — transparent WebP rendition for web use.
- `production/sizes/` — responsive derivatives at 1024, 512, 256 and 128 px (PNG + WebP).

The master character is the calm, cross-legged pose: pearl-white rounded tooth head, closed eyes, subtle blush, white coat and deep-blue scrubs, cool restrained rim lighting. Preserve this design.

## Reference boards

The `reference/` folder contains pose/expression sheets and layout examples. These are **art-direction references only**; do not place an entire board into the homepage, and do not crop small thumbnails out of a sheet and treat them as high-resolution production assets.

## Important current limitation

Only the meditating pose is supplied as a clean, standalone, high-resolution production asset in this starter pack. The boards depict potential semantic poses (guide/point, listening, thinking, studying, laptop/work, celebration, back/turnaround), but their individual cells are not production exports. Use the boards to guide composition and future pose creation, not as direct full-size website assets. The later Blender model should become the single source of truth for consistent poses and real 3D rotation.

## Character direction

- The mascot is a **helper / tour guide**, not the protagonist of every section.
- The user's needs and the product interfaces are the focal point.
- Match pose and expression semantically to the section: guide/point for walkthrough, curious/listening for AI, focused for records, reassuring for Concierge, study/work poses for Scholar and Clinic OS, rear-facing calm pose for Coming Soon.
- Keep facial design, head silhouette, coat, scrubs, proportions and material finish consistent.
- Use restraint: no exaggerated glow halo, no unnecessary neon outlines and no random costume changes.
- The Earth belongs in the hero and closing vision/Coming Soon scene, not every section.

## Suggested file placement

Copy `production/` into the FMD repository under `public/assets/mascot/` (or the equivalent static asset directory used by the project). Keep `reference/` in `docs/design-references/fmd-mascot/` so the boards inform Claude but are not accidentally rendered as page assets.

## Transparency and sharpness

The PNG master retains an alpha channel. For normal website use, select a responsive WebP derivative close to the rendered display size. Pixel dimensions alone do not guarantee detail quality; inspect edges at actual display size. Do not stretch a small derivative to use as a large hero asset.
