FMD Mascot Read — Asset Pack
============================
Purpose: Learn from Verified Dentists / learning section.

Files:
- mascot-read.png: 2048x2048 RGBA master (transparent background)
- mascot-read-1024.webp: 1024x1024 transparent website asset
- mascot-read-512.webp: 512x512 transparent website asset
- mascot-read-preview.jpg: preview composited on FMD midnight navy
- mascot-read-transparency-check.jpg: checkerboard preview to inspect alpha

Source render: 1254x1254 px.
The 2048 px master is upscaled/resampled from the generated source; its dimensions do not indicate native 2048 px detail.
The cleanup removed tiny disconnected alpha components outside the main character. Inspect the silhouette at 100% and at the intended ~120 CSS px display size before production approval.

Suggested repo location (relative to the Next.js app root):
public/img/mascots/mascot-read.png
public/img/mascots/mascot-read-1024.webp
public/img/mascots/mascot-read-512.webp
