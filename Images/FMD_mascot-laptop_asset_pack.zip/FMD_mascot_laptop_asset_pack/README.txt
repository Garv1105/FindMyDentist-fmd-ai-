FMD mascot-laptop asset pack

mascot-laptop.png: 2048x2048 transparent RGBA PNG master.
mascot-laptop-1024.webp: 1024x1024 transparent WebP.
mascot-laptop-512.webp: 512x512 transparent WebP.
Preview files are flattened examples only; do not use them as transparent assets.

Quality note: source render was 1254x1254; the 2048 PNG is upscaled/resampled, not natively rendered at 2048 px.
Design note: this generated candidate includes chair, desk and plant; it is a three-quarter view rather than strict side profile.
