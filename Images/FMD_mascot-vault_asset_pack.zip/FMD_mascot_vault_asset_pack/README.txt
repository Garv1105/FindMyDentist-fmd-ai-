FMD Mascot Vault — Asset Pack
============================
Purpose: Private Vault section; mascot holding a closed folder/document to its chest.

Files:
- mascot-vault.png: 2048x2048 RGBA PNG master (transparent background)
- mascot-vault-1024.webp: 1024x1024 transparent website asset
- mascot-vault-512.webp: 512x512 transparent website asset
- mascot-vault-preview.jpg: preview composited on FMD midnight navy
- mascot-vault-transparency-check.jpg: checkerboard preview to inspect alpha

Source render: 1254x1254 px. The 2048px master is upscaled/resampled from this source; its dimensions do not indicate native 2048px detail. Small disconnected alpha components were removed and the main alpha silhouette was retained. Inspect edges at 100% and at the intended ~120 CSS px display size before production approval.

No padlock or security badge is included. The folder is plain navy with no text.

Suggested repo location (relative to the Next.js app root):
public/img/mascots/mascot-vault.png
public/img/mascots/mascot-vault-1024.webp
public/img/mascots/mascot-vault-512.webp
