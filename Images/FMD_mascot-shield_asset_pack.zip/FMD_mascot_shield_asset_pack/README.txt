FMD mascot-shield asset pack

mascot-shield.png: 2048x2048 RGBA PNG master (upscaled from generated 1254x1254 source).
mascot-shield-1024.webp: transparent web export.
mascot-shield-512.webp: transparent web export.
Previews are JPG/PNG composites for visual inspection only; use PNG/WebP assets in the website.
Source alpha was cleaned by removing disconnected low-opacity specks outside the main silhouette.
