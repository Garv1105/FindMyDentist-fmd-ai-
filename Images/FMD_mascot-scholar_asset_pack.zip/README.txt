FMD mascot-scholar asset pack

Files:
- mascot-scholar.png: 2048x2048 transparent RGBA master. Source render was 1254x1254 and the master is resampled/upscaled; this is not native 2048px detail.
- mascot-scholar-1024.webp: transparent lossless WebP, 1024x1024.
- mascot-scholar-512.webp: transparent lossless WebP, 512x512.
- mascot-scholar-preview.jpg: composite on midnight navy.
- mascot-scholar-transparency-check.jpg: composite over a checkerboard for edge inspection.
- mascot-scholar-120px-check.jpg: approximate small-size legibility check.

Suggested use: public/img/mascots/mascot-scholar-512.webp for a ~120px on-screen display, or -1024.webp for higher-DPR flexibility.
