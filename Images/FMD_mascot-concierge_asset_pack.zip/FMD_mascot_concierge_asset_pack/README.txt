FMD mascot-concierge asset pack

mascot-concierge.png: 2048x2048 RGBA PNG master; source render enlarged/resampled from 1254x1254.
mascot-concierge-1024.webp: transparent web export.
mascot-concierge-512.webp: transparent web export.
Previews are JPEGs on navy/checkerboard backgrounds; do not use previews as production assets.
Pose: welcoming slight bow/tilt, open hand presenting a brass service bell; warm service accent.
