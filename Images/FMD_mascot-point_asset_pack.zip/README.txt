FMD mascot-point asset pack

Purpose: walkthrough timeline; mascot pointing toward the next step (right).
Master: mascot-point.png, 2048 x 2048 RGBA PNG.
Web exports: mascot-point-1024.webp and mascot-point-512.webp (alpha preserved).
Preview: mascot-point-preview.jpg (composited on midnight navy).
Transparency check: mascot-point-transparency-check.jpg (checkerboard composite).

Important: the generated source render was 1299 x 1211. The 2048 master is resampled/upscaled, not a native 2048 render. It is intended to display at about 40 CSS px; inspect the silhouette at 40 px before production approval. Detached small alpha artifacts outside the character silhouette were removed.

Suggested placement relative to the web app root:
public/img/mascots/mascot-point.png
public/img/mascots/mascot-point-512.webp
public/img/mascots/mascot-point-1024.webp
