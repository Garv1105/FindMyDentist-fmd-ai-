FMD mascot-guide refined asset pack

Files:
- mascot-guide.png             2048x2048 RGBA transparent PNG master
- mascot-guide-1024.webp       1024x1024 RGBA WebP for main website use
- mascot-guide-512.webp        512x512 RGBA WebP for smaller placement
- mascot-guide-preview.jpg     visual preview composited on midnight navy (not transparent)

Purpose:
- Section 03: AI Features
- Standing explanatory pose with an open presenting hand.
- Recommended display width: about 260 CSS px.

Preparation notes:
- Generated source image was 1254x1254; final PNG was standardized to a 2048x2048 canvas using high-quality resampling.
- Transparent alpha noise and scattered fringe artifacts were reduced and the subject was centered with clear padding.
- Upscaling does not create new fine detail missing from the source. Review at intended 260px display size and compare character identity against the approved hero mascot before production use.
- All variants preserve alpha transparency. The JPEG preview is only for visual review on a dark background.
