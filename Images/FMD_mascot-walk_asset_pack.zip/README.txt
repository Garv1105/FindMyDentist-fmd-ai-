FMD mascot-walk asset pack

Master: mascot-walk.png (2048 x 2048 RGBA PNG)
Web exports: mascot-walk-1024.webp and mascot-walk-512.webp (transparent WebP)
Preview: mascot-walk-preview.jpg
Transparency QA: mascot-walk-transparency-check.jpg
Original source: mascot-walk-source-1254.png (1254 x 1254)

Important: The generated source was 1254 x 1254; the 2048 master canvas is upscaled and does not add native detail.
Use near 44 CSS px. Confirm character identity and visual result on the actual page before production approval.
