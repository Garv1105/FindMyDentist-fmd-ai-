FMD EARTH HORIZON ASSETS

Target: wide homepage hero / 3:1 Earth-horizon band. Master canvas: 4320 x 1440 px.

1) FMD_Earth_Horizon_Original_Composition_4320x1440.png
   High-quality Lanczos resize with restrained sharpening from the exact uploaded image (Hero Earth Image.png, 2048 x 682). Preserves the approved source composition. This is a conventional upscale, not neural AI super-resolution; added pixels do not guarantee new true detail. Use as the lossless master if preserving the exact picture is most important.

2) FMD_Earth_Horizon_Original_Composition_4320x1440.webp / .avif
   Web-delivery encodings of the original-composition master. Prefer AVIF where supported by the project pipeline, with WebP fallback.

3) FMD_Earth_Horizon_Enhanced_Variant_4320x1440.png / .webp
   A freshly generated, composition-matched alternative inspired by the uploaded image. Some stars, clouds, lights or surface details may differ; it is not pixel-identical to the supplied image. Compare and approve before replacing the original-composition version.

INTEGRATION
- Keep the Earth image static.
- Draw the animated C-shaped horizon glow as a separate SVG/CSS layer aligned to the visible horizon.
- Keep the mascot independent from the Earth background.
- Do not bake animated glow into the base plate.

QUALITY NOTE
The 4320 x 1440 dimensions are output dimensions. The exact-composition file is resized from the 2048 x 682 source; for true AI-reconstructed detail, run the source through a dedicated upscaler with a conservative landscape/photo model, then inspect clouds, stars, city lights and the atmospheric rim at 100%.
